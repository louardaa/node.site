

import {
  mobile,
  backend,
  creator,
  web,
  javascript,
  typescript,
  css,
  reactjs,
  redux,
  tailwind,
  nodejs,
  mongodb,
  git,
  figma,
  docker,
  blender,
  threejs,
  tren3,
  tren2,
  tren,
} from "../assets";




export const navLinks = [
  {
    id: "about",
    title: "Hakkımda",
  },
  {
    id: "work",
    title: "Çalışmalarım",
  },
  {
    id: "contact",
    title: "İletişim",
  },
];

const services = [
  {
    title: "Blender",
    icon: web,
  },
  {
    title: "Modeelleme",
    icon: mobile,
  },
  {
    title: "Tasarım",
    icon: backend,
  },
  {
    title: "Animasyon",
    icon: creator,
  },
];

const technologies = [
  {
    name: "Blender",
    icon: blender,
  },
  {
    name: "CSS 3",
    icon: css,
  },
  {
    name: "JavaScript",
    icon: javascript,
  },
  {
    name: "TypeScript",
    icon: typescript,
  },
  {
    name: "React JS",
    icon: reactjs,
  },
  {
    name: "Redux Toolkit",
    icon: redux,
  },
  {
    name: "Tailwind CSS",
    icon: tailwind,
  },

 
];


const experiences = [
  {
    title: "Blender modeling",
    company_name: "Blender",
    icon: blender,
    iconBg: "#383E56",
    points: [
      "1.",
      "2",
      "3",
      "4",
    ],
    img:"https://images.unsplash.com/photo-1690983182312-118fd81ea805?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=764&q=80"
  },
 
  {
    title: "Blender modeling",
    company_name: "Blender",
    icon: blender,
    iconBg: "#383E56",

    points: [
      "1.",
      "2",
      "3",
      "4",
    ],
  },
  {

    title: "Blender modeling",
    company_name: "Blender2",
    icon: blender,
    iconBg: "#383E56",

    points: [
      "1.",
      "2",
      "3",
      "4",
    ],
  },
  
  {
   
    title: "Blender modeling",
    company_name: "Blender3",
    icon: blender,
    iconBg: "#383E56",

    points: [
      "1.",
      "2",
      "3",
      "4",
    ],
  },
  
];

const testimonials = [
  {
    testimonial:
      "I thought it was impossible to make a website as beautiful as our product, but Rick proved me wrong.",
    name: "Sara Lee",
    designation: "CFO",
    company: "Acme Co",
    image: "https://randomuser.me/api/portraits/women/4.jpg",
  },
  {
    testimonial:
      "I've never met a web developer who truly cares about their clients' success like Rick does.",
    name: "Chris Brown",
    designation: "COO",
    company: "DEF Corp",
    image: "https://randomuser.me/api/portraits/men/5.jpg",
  },
  {
    testimonial:
      "After Rick optimized our website, our traffic increased by 50%. We can't thank them enough!",
    name: "Lisa Wang",
    designation: "CTO",
    company: "456 Enterprises",
    image: "https://randomuser.me/api/portraits/women/6.jpg",
  },
];

const projects = [
  {
    name: "1. Model",
    description:
      "1",
    tags: [
      {
        name: "Blend",
        color: "blue-text-gradient",
      },
      {
        name: "PS",
        color: "green-text-gradient",
      },
      {
        name: "Adobe",
        color: "pink-text-gradient",
      },
    ],
    image: tren,
    source_code_link: "https://github.com/recpin",
  },
  {
    name: "2. Model",
    description:
      "2",
    tags: [
      {
        name: "Blend",
        color: "blue-text-gradient",
      },
      {
        name: "PS",
        color: "green-text-gradient",
      },
      {
        name: "Adobe",
        color: "pink-text-gradient",
      },
    ],
    image: tren2,
    source_code_link: "https://github.com/recpin",
  },
  {
    name: "3.Model",
    description:
      "3",
    tags: [
      {
        name: "Blend",
        color: "blue-text-gradient",
      },
      {
        name: "PS",
        color: "green-text-gradient",
      },
      {
        name: "Adobe",
        color: "pink-text-gradient",
      },
    ],
    image: tren3,
    source_code_link: "https://github.com/recpin",
  },
];

export { services, technologies, experiences, testimonials, projects };





















